module Collision where

import Model